-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2021 at 12:11 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bigburger`
--
CREATE DATABASE IF NOT EXISTS `bigburger` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bigburger`;

-- --------------------------------------------------------

--
-- Table structure for table `ingrediants`
--

DROP TABLE IF EXISTS `ingrediants`;
CREATE TABLE `ingrediants` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `storage` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `content` varchar(250) NOT NULL,
  `type_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ingrediants`
--

INSERT INTO `ingrediants` (`id`, `name`, `value`, `storage`, `unit`, `price`, `content`, `type_id`, `quantity`, `vendor_id`, `created_at`, `updated_at`) VALUES
(1, 'aa', 'aa', 'aa', 'aa', 15, '15', 2, 15, 1, '2021-12-09 20:20:20', '2021-12-09 20:20:20');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `item_name` varchar(50) NOT NULL,
  `ingrediant_id` int(11) NOT NULL,
  `qts` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inventory`
--

INSERT INTO `inventory` (`id`, `item_name`, `ingrediant_id`, `qts`, `vendor_id`, `type_id`, `created_at`, `updated_at`) VALUES
(1, 'adsd', 1, 10, 1, 2, '2021-12-09 23:20:19', '2021-12-09 23:20:19');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'aa', '2021-12-09 14:49:16', '2021-12-09 14:49:16'),
(2, 'ok', '2021-12-09 14:53:23', '2021-12-09 16:08:52'),
(4, 'aa', '2021-12-09 15:44:08', '2021-12-09 15:44:08');

-- --------------------------------------------------------

--
-- Table structure for table `menu_item`
--

DROP TABLE IF EXISTS `menu_item`;
CREATE TABLE `menu_item` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `ingrediants` varchar(250) NOT NULL,
  `active` int(1) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL,
  `price` float NOT NULL,
  `tax` float NOT NULL,
  `menu_id` int(11) NOT NULL,
  `grand_total` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu_item`
--

INSERT INTO `menu_item` (`ID`, `name`, `ingrediants`, `active`, `summary`, `image`, `price`, `tax`, `menu_id`, `grand_total`) VALUES
(2, '20.0', '20.0', 0, '00', '', 20, 20, 1, '20');

-- --------------------------------------------------------

--
-- Table structure for table `non_ingrediants_products`
--

DROP TABLE IF EXISTS `non_ingrediants_products`;
CREATE TABLE `non_ingrediants_products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `value` varchar(50) NOT NULL,
  `storage` varchar(50) NOT NULL,
  `unit` varchar(50) NOT NULL,
  `price` float NOT NULL,
  `content` varchar(200) NOT NULL,
  `type_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `non_ingrediants_products`
--

INSERT INTO `non_ingrediants_products` (`id`, `name`, `value`, `storage`, `unit`, `price`, `content`, `type_id`, `quantity`, `vendor_id`, `created_at`, `updated_at`) VALUES
(2, 'ccc', 'dsd', 'fdf', 'fdf', 15, 'fdf', 2, 14, 1, '2021-12-09 20:21:26', '2021-12-09 22:28:17'),
(4, 'aa', 'aa', 'ff', 'fd', 45, '20', 2, 10, 1, '2021-12-09 22:31:20', '2021-12-09 22:31:20');

-- --------------------------------------------------------

--
-- Table structure for table `restock_orders`
--

DROP TABLE IF EXISTS `restock_orders`;
CREATE TABLE `restock_orders` (
  `id` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `grand_total` float NOT NULL,
  `inventory_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restock_orders`
--

INSERT INTO `restock_orders` (`id`, `status`, `grand_total`, `inventory_id`, `created_at`, `updated_at`) VALUES
(1, 'aaa', 200, 1, '2021-12-09 23:50:53', '2021-12-10 00:01:03'),
(2, 'bb', 100, 1, '2021-12-09 23:51:55', '2021-12-09 23:51:55');

-- --------------------------------------------------------

--
-- Table structure for table `types`
--

DROP TABLE IF EXISTS `types`;
CREATE TABLE `types` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `types`
--

INSERT INTO `types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(2, 'cc', '2021-12-09 16:22:14', '2021-12-09 16:22:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'aa', 'aa', 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

DROP TABLE IF EXISTS `vendors`;
CREATE TABLE `vendors` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `content` varchar(250) NOT NULL,
  `product` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `name`, `created_at`, `updated_at`, `content`, `product`) VALUES
(1, 'aa', '2021-12-09 16:42:06', '2021-12-09 16:42:06', 'aa', 'aa'),
(3, 'aa', '2021-12-09 16:43:11', '2021-12-09 16:43:11', 'aa', 'aa'),
(4, 'dd', '2021-12-09 16:44:12', '2021-12-09 16:55:30', 'aa', 'aa'),
(5, 'aa', '2021-12-09 16:47:26', '2021-12-09 16:47:26', 'aa', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ingrediants`
--
ALTER TABLE `ingrediants`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vendor` (`vendor_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx1` (`vendor_id`),
  ADD KEY `idx2` (`type_id`),
  ADD KEY `idx3` (`ingrediant_id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_item`
--
ALTER TABLE `menu_item`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `menu` (`menu_id`);

--
-- Indexes for table `non_ingrediants_products`
--
ALTER TABLE `non_ingrediants_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `type` (`type_id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `restock_orders`
--
ALTER TABLE `restock_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `types`
--
ALTER TABLE `types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ingrediants`
--
ALTER TABLE `ingrediants`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `menu_item`
--
ALTER TABLE `menu_item`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `non_ingrediants_products`
--
ALTER TABLE `non_ingrediants_products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `restock_orders`
--
ALTER TABLE `restock_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `types`
--
ALTER TABLE `types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
