package models;

import java.util.Date;

public class Product {

    private int id;
    private String name;
    private String value;
    private String storage;
    private String unit;
    private double price;
    private String content;
    private Type type;
    private int quantity;
    private Vendor vendor;
    private Date createdAt;
    private Date updatedAt;
    private boolean isIngrediant;

    public Product(int id, String name, String value, String storage, String unit, double price, String content, Type type, int quantity, Vendor vendor, Date createdAt, Date updatedAt, boolean isIngrediant) {
        this.id = id;
        this.name = name;
        this.value = value;
        this.storage = storage;
        this.unit = unit;
        this.price = price;
        this.content = content;
        this.type = type;
        this.quantity = quantity;
        this.vendor = vendor;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.isIngrediant = isIngrediant;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public String getStorage() {
        return storage;
    }

    public void setStorage(String storage) {
        this.storage = storage;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean isIsIngrediant() {
        return isIngrediant;
    }

    public void setIsIngrediant(boolean isIngrediant) {
        this.isIngrediant = isIngrediant;
    }

    @Override
    public String toString() {
        return name;
    }

}
