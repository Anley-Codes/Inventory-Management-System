package models;

public class MenuItem {

    private int id;
    private String name;
    private String ingrediants;
    private boolean active;
    private String summary;
    private String image;
    private double price;
    private double tax;
    private Menu menu;
    private double grandTotal;

    public MenuItem(int id, String name, String ingrediants, boolean active, String summary, String image, double price, double tax, Menu menu, double grandTotal) {
        this.id = id;
        this.name = name;
        this.ingrediants = ingrediants;
        this.active = active;
        this.summary = summary;
        this.image = image;
        this.price = price;
        this.tax = tax;
        this.menu = menu;
        this.grandTotal = grandTotal;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getIngrediants() {
        return ingrediants;
    }

    public void setIngrediants(String ingrediants) {
        this.ingrediants = ingrediants;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public Menu getMenu() {
        return menu;
    }

    public void setMenu(Menu menu) {
        this.menu = menu;
    }

    public double getGrandTotal() {
        return grandTotal;
    }

    public void setGrandTotal(double grandTotal) {
        this.grandTotal = grandTotal;
    }

    @Override
    public String toString() {
        return "MenuItem{" + "id=" + id + ", name=" + name + ", ingrediants=" + ingrediants + ", active=" + active + ", summary=" + summary + ", image=" + image + ", price=" + price + ", tax=" + tax + ", menu=" + menu + ", grandTotal=" + grandTotal + '}';
    }

    
    
    
    
}
