package models;

import java.util.Date;

/**
 *
 * @author pc
 */
public class Menu {

    private int id;
    private String name;
    private Date createdAt;
    private Date updatedAt;

    public Menu(int id, String name, Date createdAt, Date updatddAt) {
        this.id = id;
        this.name = name;
        this.createdAt = createdAt;
        this.updatedAt = updatddAt;
    }

    public Menu(String name) {
        this.name = name;
        this.createdAt = new Date();
        this.updatedAt = new Date();
    }

    public Menu(int id, String name, Date updatddAt) {
        this.id = id;
        this.name = name;
        this.updatedAt = updatddAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return name;
    }

}
