package models;

import java.util.Date;

public class Inventory {

    private int id;
    private String itemName;
    private Product product;
    private int quantity;
    private Vendor vendor;
    private Type type;
    private Date createdAt;
    private Date updatedAt;

    public Inventory(int id, String itemName, Product product, int quantity, Vendor vendor, Type type, Date createdAt, Date updatedAt) {
        this.id = id;
        this.itemName = itemName;
        this.product = product;
        this.quantity = quantity;
        this.vendor = vendor;
        this.type = type;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "Inventory{" + "id=" + id + ", vendor=" + vendor + ", type=" + type + ", product=" + product + ", itemName=" + itemName + ", quantity=" + quantity + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt + '}';
    }

}
