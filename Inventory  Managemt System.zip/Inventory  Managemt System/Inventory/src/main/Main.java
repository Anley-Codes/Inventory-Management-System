package main;

import forms.*;

public class Main {

    public final static CreateAccountForm CREATE_ACCOUNT_FORM = new CreateAccountForm();
    public final static Forms FORMS = new Forms();
    public final static InventoryForm INVENTORY_FORM = new InventoryForm();
    public final static LoginForm LOGIN_FORM = new LoginForm();
    public final static MenuForm MENU_FORM = new MenuForm();
    public final static MenuItemForm MENU_ITEM_FORM = new MenuItemForm();
    public final static ProductsForm PRODUCTS_FORM = new ProductsForm();
    public final static RestockOrdersForm RESTOCK_ORDERS_FORM = new RestockOrdersForm();
    public final static TypesForm TYPES_FORM = new TypesForm();
    public final static VendorsForm VENDORS_FORM = new VendorsForm();

    public static void main(String[] args) {
        LOGIN_FORM.setVisible(true);
    }
}
