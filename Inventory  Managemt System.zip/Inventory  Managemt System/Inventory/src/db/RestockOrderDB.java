package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.*;
import java.util.Date;
import java.util.List;

public class RestockOrderDB {

    public static List<RestockOrder> select() {
        String sql = "select * from  restock_orders";
        List<RestockOrder> restocks = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("status");
                double grand_total = resultSet.getDouble("grand_total");
                int inventory_id = resultSet.getInt("inventory_id");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                RestockOrder order = new RestockOrder(id, name, grand_total, InventoryDB.getById(inventory_id), createdAt, updateAt);
                restocks.add(order);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return restocks;
    }

    public static void insert(RestockOrder p) {
        String sql = "insert into restock_orders (status,grand_total,inventory_id,created_at,updated_at) values (?,?,?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, p.getStatus());
            preparedStatement.setDouble(2, p.getGrandTotal());
            preparedStatement.setInt(3, p.getInventory().getId());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(5, new java.sql.Timestamp(p.getUpdatedAt().getTime()));

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void update(RestockOrder p) {
        String sql = "update restock_orders set status = ? ,grand_total = ? ,inventory_id = ? ,updated_at = ? where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, p.getStatus());
            preparedStatement.setDouble(2, p.getGrandTotal());
            preparedStatement.setInt(3, p.getInventory().getId());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setInt(5, p.getId());
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(RestockOrder p) {
        String sql = "delete from restock_orders where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setInt(1, p.getId());
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
