package db;

import java.util.List;
import models.*;
import java.sql.*;

public class UserDB {

    public static boolean insert(User p) {
        if (roleExists(p)) {
            return false;
        }
        String SQL_INSERT = "INSERT INTO USERS (USERNAME, PASSWORD, ROLE) VALUES (?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT)) {

            preparedStatement.setString(1, p.getUsername());
            preparedStatement.setString(2, p.getPassword());
            preparedStatement.setString(3, p.getRole());

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    public static boolean roleExists(User user) {
        String SQL_SELECT = "SELECT * FROM USERS WHERE role=?";

        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setString(1, user.getRole());
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String username = resultSet.getString("USERNAME");
                String password = resultSet.getString("PASSWORD");
                String role = resultSet.getString("ROLE");

                User u = new User(id, username, password, role);
                return true;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static User login(User user) {
        String SQL_SELECT = "SELECT * FROM USERS WHERE username=? and password=? and role=?";

        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getPassword());
            preparedStatement.setString(3, user.getRole());
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String username = resultSet.getString("USERNAME");
                String password = resultSet.getString("PASSWORD");
                String role = resultSet.getString("ROLE");

                User u = new User(id, username, password, role);
                return u;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
