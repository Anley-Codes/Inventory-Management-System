package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.*;
import java.util.Date;
import java.util.List;

public class VendorDB {

    public static List<Vendor> select(String keyword) {
        String SQL_SELECT = "SELECT * FROM Vendors";
        if (keyword != null) {
            SQL_SELECT += " where name like '%" + keyword + "%'";
        }
        List<Vendor> vendors = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                String content = resultSet.getString("content");
                String product = resultSet.getString("product");

                Vendor v = new Vendor(id, name, content, product, createdAt, updateAt);
                vendors.add(v);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vendors;
    }

    public static boolean insert(Vendor p) {
        String SQL_INSERT = "INSERT INTO VENDORS(`name`, `content`, `product`, `created_at` ,`updated_at`) VALUES (?,?,?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getContent());
            preparedStatement.setString(3, p.getProduct());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(5, new java.sql.Timestamp(p.getUpdatedAt().getTime()));
            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }

    public static void update(Vendor p) {
        String SQL = "update vendors set `name` =? ,`content` = ? , `product` = ? , `updated_at` = ? where `id`=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getContent());
            preparedStatement.setString(3, p.getProduct());
            preparedStatement.setTimestamp(4, new java.sql.Timestamp(new Date().getTime()));
            preparedStatement.setInt(5, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(Vendor p) {
        String SQL = "delete from vendors where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setInt(1, p.getId());
            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Vendor getById(int id) {
        String SQL_SELECT = "SELECT * FROM Vendors where id = ?";
        List<Vendor> vendors = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println(preparedStatement);
            while (resultSet.next()) {
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                String content = resultSet.getString("content");
                String product = resultSet.getString("product");
                Vendor v = new Vendor(id, name, content, product, createdAt, updateAt);
                return v;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static Vendor getByName(String name) {
        String SQL_SELECT = "SELECT * FROM Vendors where name = ?";
        List<Vendor> vendors = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name1 = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                String content = resultSet.getString("content");
                String product = resultSet.getString("product");

                Vendor v = new Vendor(id, name1, content, product, createdAt, updateAt);
                return v;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
