package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import models.*;

public class MenuItemDB {

    public static List<MenuItem> select(Menu mi, String keyword) {
        String sql = "select * from menu_item where menu_id = ?";
        if (keyword != null) {
            sql += " and name like '%" + keyword + "%'";
        }
        List<MenuItem> menu_items = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, mi.getId());
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                String ingrediants = resultSet.getString("ingrediants");
                int active = resultSet.getInt("active");
                String summary = resultSet.getString("summary");
                String image = resultSet.getString("image");
                double price = resultSet.getDouble("price");
                double tax = resultSet.getDouble("tax");
                double grandTotal = resultSet.getDouble("grand_total");

                MenuItem m = new MenuItem(id, name, ingrediants, active == 1, summary, image, price, tax, mi, grandTotal);
                menu_items.add(m);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return menu_items;
    }

    public static void insert(MenuItem p) {
        String SQL_INSERT = "INSERT INTO menu_item (name,ingrediants,active,summary,price,tax,menu_id,grand_total,image) VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getIngrediants());
            preparedStatement.setInt(3, p.isActive() ? 1 : 0);
            preparedStatement.setString(4, p.getSummary());
            preparedStatement.setDouble(5, p.getPrice());
            preparedStatement.setDouble(6, p.getTax());
            preparedStatement.setInt(7, p.getMenu().getId());
            preparedStatement.setDouble(8, p.getGrandTotal());
            preparedStatement.setString(9, "");

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void update(MenuItem p) {
        String SQL = "update menu_item set name =? , ingrediants = ? , active = ?  ,summary=?,price=?,tax=?,menu_id=?,grand_total=? where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getIngrediants());
            preparedStatement.setInt(3, p.isActive() ? 1 : 0);
            preparedStatement.setString(4, p.getSummary());
            preparedStatement.setDouble(5, p.getPrice());
            preparedStatement.setDouble(6, p.getTax());
            preparedStatement.setInt(7, p.getMenu().getId());
            preparedStatement.setDouble(8, p.getGrandTotal());
            preparedStatement.setInt(9, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(MenuItem p) {
        String SQL = "delete from menu_item where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setInt(1, p.getId());
            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
