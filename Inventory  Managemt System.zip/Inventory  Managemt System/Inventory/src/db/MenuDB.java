package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.*;
import java.util.Date;
import java.util.List;

/**
 *
 * @author pc
 */
public class MenuDB {

    public static List<Menu> select(String keyword) {
        String SQL_SELECT = "SELECT * FROM MENU";;
        if (keyword != null) {
            SQL_SELECT += " where name like '%" + keyword + "%'";
        }

        List<Menu> menus = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Menu m = new Menu(id, name, createdAt, updateAt);
                menus.add(m);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return menus;
    }

    public static void insert(Menu p) {
        String SQL_INSERT = "INSERT INTO MENU (NAME, created_at, updated_at) VALUES (?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setTimestamp(2, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(3, new java.sql.Timestamp(p.getUpdatedAt().getTime()));

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void update(Menu p) {
        String SQL = "update MENU set name =? , updated_at = ? where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setTimestamp(2, new java.sql.Timestamp(new Date().getTime()));
            preparedStatement.setInt(3, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(Menu p) {
        String SQL = "delete from MENU where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setInt(1, p.getId());
            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Menu getById(int menuId) {
        String SQL_SELECT = "SELECT * FROM MENU whenre id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setInt(1, menuId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Menu m = new Menu(id, name, createdAt, updateAt);
                return m;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
