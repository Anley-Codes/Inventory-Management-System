package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import models.*;

public class ProductDB {

    public static List<Product> select(String keyword) {
        String SQL1 = "SELECT * FROM ingrediants";
        String SQL2 = "select * from non_ingrediants_products";
        if (keyword != null) {
            SQL1 += "where name like '%" + keyword + "%'";
            SQL2 += "where name like '%" + keyword + "%'";
        }
        List<Product> products = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL1)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                String value = resultSet.getString("value");
                String storage = resultSet.getString("storage");
                String unit = resultSet.getString("unit");
                double price = resultSet.getDouble("price");
                String content = resultSet.getString("content");
                Type type = TypeDB.getById(resultSet.getInt("type_id"));
                Vendor vendor = VendorDB.getById(resultSet.getInt("vendor_id"));
                int quantity = resultSet.getInt("quantity");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Product m = new Product(id, name, value, storage, unit, price, content, type, quantity, vendor, createdAt, updateAt, true);
                products.add(m);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL2)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                String value = resultSet.getString("value");
                String storage = resultSet.getString("storage");
                String unit = resultSet.getString("unit");
                double price = resultSet.getDouble("price");
                String content = resultSet.getString("content");
                Type type = TypeDB.getById(resultSet.getInt("type_id"));
                Vendor vendor = VendorDB.getById(resultSet.getInt("vendor_id"));
                int quantity = resultSet.getInt("quantity");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Product m = new Product(id, name, value, storage, unit, price, content, type, quantity, vendor, createdAt, updateAt, false);
                products.add(m);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return products;
    }

    public static void insert(Product p) {
        String SQL1 = "INSERT INTO `non_ingrediants_products` (`name`, `value`, `storage`, `unit`, `price`, `content`, `type_id`, `quantity`, `vendor_id`, `created_at`, `updated_at`) VALUES (?, ?, ?, ?, ? , ? , ? , ? ,  ? , ? , ?);";
        String SQL2 = "INSERT INTO `ingrediants` (`name`, `value`, `storage`, `unit`, `price`, `content`, `type_id`, `quantity`, `vendor_id`, `created_at`, `updated_at`) VALUES (?, ?, ?, ?, ? , ? , ? , ? ,  ? , ? , ?);";

        try {
            Connection conn = MysqlDB.getConnection();
            String sql = (!p.isIsIngrediant() ? SQL1 : SQL2);
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getValue());
            preparedStatement.setString(3, p.getStorage());
            preparedStatement.setString(4, p.getUnit());
            preparedStatement.setDouble(5, p.getPrice());
            preparedStatement.setString(6, p.getContent());
            preparedStatement.setInt(7, p.getType().getId());
            preparedStatement.setInt(8, p.getQuantity());
            preparedStatement.setInt(9, p.getVendor().getId());
            preparedStatement.setTimestamp(10, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(11, new java.sql.Timestamp(p.getUpdatedAt().getTime()));

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void update(Product p) {
        String sql1 = "update non_ingrediants_products set `name` = ? , `value`  = ? , `storage`  = ? , `unit`  = ? , `price`  = ? , `content`  = ? , `type_id`  = ? , `quantity`  = ? , `vendor_id`  = ? , `updated_at`  = ? where id = ?";
        String sql2 = "update ingrediants set `name` = ? , `value`  = ? , `storage`  = ? , `unit`  = ? , `price`  = ? , `content`  = ? , `type_id`  = ? , `quantity`  = ? , `vendor_id`  = ? , `updated_at`  = ? where id = ?";

        try {
            Connection conn = MysqlDB.getConnection();
            String sql = (p.isIsIngrediant() ? sql2 : sql1);
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setString(1, p.getName());
            preparedStatement.setString(2, p.getValue());
            preparedStatement.setString(3, p.getStorage());
            preparedStatement.setString(4, p.getUnit());
            preparedStatement.setDouble(5, p.getPrice());
            preparedStatement.setString(6, p.getContent());
            preparedStatement.setInt(7, p.getType().getId());
            preparedStatement.setInt(8, p.getQuantity());
            preparedStatement.setInt(9, p.getVendor().getId());
            preparedStatement.setTimestamp(10, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setInt(11, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row + " ******************"); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(Product p) {
        String sql1 = "delete from non_ingrediants_products where id = ?";
        String sql2 = "delete from ingrediants where id = ?";

        try {
            Connection conn = MysqlDB.getConnection();
            String sql = (p.isIsIngrediant() ? sql2 : sql1);
            PreparedStatement preparedStatement = conn.prepareStatement(sql);
            preparedStatement.setInt(1, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row + " ******************"); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Product getById(int id) {
        String SQL1 = "SELECT * FROM ingrediants where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL1)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String name = resultSet.getString("name");
                String value = resultSet.getString("value");
                String storage = resultSet.getString("storage");
                String unit = resultSet.getString("unit");
                double price = resultSet.getDouble("price");
                String content = resultSet.getString("content");
                Type type = TypeDB.getById(resultSet.getInt("type_id"));
                Vendor vendor = VendorDB.getById(resultSet.getInt("vendor_id"));
                int quantity = resultSet.getInt("quantity");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Product m = new Product(id, name, value, storage, unit, price, content, type, quantity, vendor, createdAt, updateAt, true);
                return m;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
