package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.*;
import java.util.Date;
import java.util.List;

/**
 *
 * @author pc
 */
public class TypeDB {

    public static List<Type> select(String keyword) {
        String SQL_SELECT = "SELECT * FROM Types";
        if (keyword != null) {
            SQL_SELECT += " where name like '%" + keyword + "%'";
        }
        List<Type> types = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Type m = new Type(id, name, createdAt, updateAt);
                types.add(m);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return types;
    }

    public static Type getById(int id) {
        String SQL_SELECT = "SELECT * FROM Types where id = ?";
        List<Type> types = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setInt(1, id);
            System.out.println(preparedStatement);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {

                int id1 = resultSet.getInt("ID");
                String name = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Type m = new Type(id, name, createdAt, updateAt);
                return m;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static Type getByName(String name) {
        String SQL_SELECT = "SELECT * FROM Types where name = ?";
        List<Type> types = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_SELECT)) {
            preparedStatement.setString(1, name);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {

                int id = resultSet.getInt("ID");
                String name1 = resultSet.getString("name");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");

                Type m = new Type(id, name1, createdAt, updateAt);
                return m;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public static void insert(Type p) {
        String SQL_INSERT = "INSERT INTO Types (NAME, created_at, updated_at) VALUES (?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL_INSERT)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setTimestamp(2, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(3, new java.sql.Timestamp(p.getUpdatedAt().getTime()));

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void update(Type p) {
        String SQL = "update Types set name =? , updated_at = ? where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setString(1, p.getName());
            preparedStatement.setTimestamp(2, new java.sql.Timestamp(new Date().getTime()));
            preparedStatement.setInt(3, p.getId());

            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void delete(Type p) {
        String SQL = "delete from Types where id=?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(SQL)) {

            preparedStatement.setInt(1, p.getId());
            System.out.println(preparedStatement);
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
