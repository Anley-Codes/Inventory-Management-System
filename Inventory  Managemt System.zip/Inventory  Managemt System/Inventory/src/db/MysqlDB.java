package db;

import java.sql.*;

public class MysqlDB {

    public static Connection getConnection() {
        try {
            // create our mysql database connection
            String myDriver = "org.gjt.mm.mysql.Driver";
            String myUrl = "jdbc:mysql://localhost/bigburger";
            Class.forName(myDriver);
            Connection connection = DriverManager.getConnection(myUrl, "root", "");

            return connection;
        } catch (Exception e) {
            System.err.println("Got an exception! ");
            System.err.println(e.getMessage());
            return null;
        }
    }
}
