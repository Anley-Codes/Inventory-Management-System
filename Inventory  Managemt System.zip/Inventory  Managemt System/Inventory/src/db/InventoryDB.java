package db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import models.*;
import java.util.Date;
import java.util.List;

public class InventoryDB {

    public static List<Inventory> select() {
        String sql = "select * from  inventory";
        List<Inventory> inventories = new ArrayList<>();
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("item_name");
                int ingrediant_id = resultSet.getInt("ingrediant_id");
                int quantity = resultSet.getInt("qts");
                int vendor_id = resultSet.getInt("vendor_id");
                int type_id = resultSet.getInt("type_id");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                Inventory inventory = new Inventory(id, name, ProductDB.getById(ingrediant_id), quantity, VendorDB.getById(vendor_id), TypeDB.getById(type_id), createdAt, updateAt);
                inventories.add(inventory);
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return inventories;
    }

    public static void insert(Inventory p) {
        String sql = "insert into inventory (item_name,ingrediant_id,qts,vendor_id,type_id,created_at,updated_at) values (?,?,?,?,?,?,?)";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, p.getItemName());
            preparedStatement.setInt(2, p.getProduct().getId());
            preparedStatement.setInt(3, p.getQuantity());
            preparedStatement.setInt(4, p.getVendor().getId());
            preparedStatement.setInt(5, p.getType().getId());
            preparedStatement.setTimestamp(6, new java.sql.Timestamp(p.getCreatedAt().getTime()));
            preparedStatement.setTimestamp(7, new java.sql.Timestamp(p.getUpdatedAt().getTime()));

            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void update(Inventory p) {
        String sql = "update inventory set item_name = ? ,ingrediant_id  = ? ,qts  = ? ,vendor_id = ? ,type_id = ? ,updated_at = ? where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setString(1, p.getItemName());
            preparedStatement.setInt(2, p.getProduct().getId());
            preparedStatement.setInt(3, p.getQuantity());
            preparedStatement.setInt(4, p.getVendor().getId());
            preparedStatement.setInt(5, p.getType().getId());
            preparedStatement.setTimestamp(6, new java.sql.Timestamp(p.getUpdatedAt().getTime()));
            preparedStatement.setInt(7, p.getId());
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void delete(Inventory p) {
        String sql = "delete from inventory where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {

            preparedStatement.setInt(1, p.getId());
            int row = preparedStatement.executeUpdate();
            // rows affected
            System.out.println(row); //1

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Inventory getById(int inventory_id) {
        String sql = "select * from  inventory where id = ?";
        try (Connection conn = MysqlDB.getConnection();
                PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
            preparedStatement.setInt(1, inventory_id);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String name = resultSet.getString("item_name");
                int ingrediant_id = resultSet.getInt("ingrediant_id");
                int quantity = resultSet.getInt("qts");
                int vendor_id = resultSet.getInt("vendor_id");
                int type_id = resultSet.getInt("type_id");
                Date createdAt = resultSet.getTimestamp("created_at");
                Date updateAt = resultSet.getTimestamp("updated_at");
                Inventory inventory = new Inventory(id, name, ProductDB.getById(ingrediant_id), quantity, VendorDB.getById(vendor_id), TypeDB.getById(type_id), createdAt, updateAt);
                return inventory;
            }

        } catch (SQLException e) {
            System.err.format("SQL State: %s\n%s", e.getSQLState(), e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
